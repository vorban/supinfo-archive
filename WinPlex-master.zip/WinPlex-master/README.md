# WinPlex
3WIN Project - Target : Windows Universal App

## Context
The app is supposed to be a "showcase of talent at creating cool and innovative apps for the Windows 10 platform" => It's actually going to be a lyrics app.

**Why ?** Because every student is probably going to upload another generic boring Weather app, and I wanted something a bit different.

APIs that I used :
- [lyrics.ovh](https://lyricsovh.docs.apiary.io/#reference/0/lyrics-of-a-song/search?console=1)
- [Vimeo](https://developer.vimeo.com/)

Lyrics.ovh is a completely unauthenticated API. Just send a HTTP-GET request and you're done. Vimeo's API uses OAuth2 authentication. Yet, as there's no need for the app users to be connected to their Vimeo account (they'll just be watching videos, nothing more), the app uses it's own Vimeo's unauthenticated token, which allows WinPlex to access content using it's own ID. No user information ever required !

## What's expected
The project will be challenged on five categories :
- [x] Internet : Internet access, network management, and data serialization
- [ ] Mobility : Device orientation, visual state re-architecture and device families
- [x] Persistence : Lifecycle management and local/roaming data Storage
- [ ] Interactivity : Background tasks, notifications and live tiles
- [ ] Geolocation : Location sensors (Magnetometer, compass, ...), Bing Maps API

Each category is evaluated as followed :

Complexity | Relevance | Stability
---------- | --------- | ---------
2 | 1.5 | 1.5

Extra points can be earned :
* UI and UX : + 1 pts
* Code quality and conventions : + 2 pts
* App Description : + 2 pts

The goal is to create and application that embraces one or more of these categories, and is coherent as a whole.
The mark will be the sum of every earned points in all categories. As a result, the maximum obtainable mark is 30/20.

## What I planned
WinPlex is going to be a lyrics app.
- [x] The user can alter settings
	* Light/Dark theme
- [x] App settings are saved
- [x] The user can search for a song using the following informations : _Artist Name - Song title_
- [x] When displaying the result, the app shows on one hand the lyrics in a scrollable styled area
- [x] On the other hand a video player, linked to the first video result from vimeo
	- [ ] _(optional)_ The video can be played while in the background
	- [ ] _(optional)_ Show first 10 results, then user choose the one to play
