﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using WinPlex.Models;
using WinPlex.Models.APIs;

namespace WinPlex
{
    public sealed partial class MainPage : Page
    {
		public ViewModel ViewModel = new ViewModel();

		public MainPage()
		{
			// load vimeo client once -> init + get token, quickens up the first video request
			VimeoClient.GetVimeoClient();

			DataContext = ViewModel;
			if (DataPersistenceManager.GetDataPersistenceManager().Contains("theme"))
			this.RequestedTheme = (ElementTheme) DataPersistenceManager.GetDataPersistenceManager().GetSetting("theme");
			this.InitializeComponent();
        }

		public void SearchBox_Query_Handler(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
		{
			// 0. Check for Internet Connection
			if (!ConnectivityManager.GetConnectivityManager().InternetAccessible)
			{
				ShowToastNotification("Internet connection failed", "Could not connect to the Internet. Please check your networking settings.");
				return;
			}

			// 1. Parse queryText
			// 2. Show that app is searching
			// 3. Query lyrics					3b. Query Vimeo for content
			// 4. Hide "app is searching"
			// 5. Update lyrics binding			5b. Update Videos binding + change visual to show it

			Tuple<String, String> queryParams = ParseSearchBoxText(sender.Text);
			
			sender.Text = "";
			if (queryParams == null)
				return;
			if (String.IsNullOrEmpty(queryParams.Item1) && String.IsNullOrEmpty(queryParams.Item2))
				return;

			UpdateLyricsAsync(queryParams);
			NavigateToVideo(queryParams);
		}

		private async void UpdateLyricsAsync(Tuple<String, String> queryParams)
		{
			SearchBox.PlaceholderText = "Searching ...";
			ViewModel.Song = await LyricsFetcher.GetFetcher().FetchLyricsAsync(queryParams);
			SearchBox.PlaceholderText = "Artist - Title";
		}

		private async void NavigateToVideo(Tuple<String, String> queryParams)
		{
			String link = await VimeoClient.GetVimeoClient().GetFirstVideoLink(queryParams);
			if (link != "") VideoWebView.Source = new Uri(link);
		}
		private Tuple<String, String> ParseSearchBoxText(String text)
		{
			Tuple<String, String> pair = null;
			try
			{
				String[] t = text.Split('-');
				pair = new Tuple<String, String>(t[0].Trim(), t[1].Trim());
			} catch
			{
				SearchBox.PlaceholderText = "Bad format ! Expected: Artist - Title. Example : Edith Piaf - La Vie En Rose";
			}
			return pair;
		}

		public void ChangeThemeButton_Click(object sender, RoutedEventArgs args)
		{
			if (!DataPersistenceManager.GetDataPersistenceManager().Contains("theme"))
				DataPersistenceManager.GetDataPersistenceManager().AddSetting("theme", (int) ElementTheme.Light);

			// false = Dark ; true = Light
			if ((ElementTheme) DataPersistenceManager.GetDataPersistenceManager().GetSetting("theme") == ElementTheme.Light)
			{
				DataPersistenceManager.GetDataPersistenceManager().AddSetting("theme", (int) ElementTheme.Dark);
				// turns out UWP automatically alter icons when theme changes, so the next line isn't required.
				// (sender as AppBarButton).Icon = AssetManager.GetAssetManager().SunLightIcon;
				this.RequestedTheme = ElementTheme.Dark;
				ChangeThemeButton.Label = "Light Theme";
			} else
			{
				DataPersistenceManager.GetDataPersistenceManager().AddSetting("theme", (int) ElementTheme.Light);
				// because the icon is never changed as said above, no need to reset it.
				// (sender as AppBarButton).Icon = AssetManager.GetAssetManager().SunDarkIcon;
				this.RequestedTheme = ElementTheme.Light;
				ChangeThemeButton.Label = "Dark Theme";
			}
				
			
		}

		private void ShowToastNotification(string title, string stringContent)
		{
			// source : https://stackoverflow.com/questions/37541923/how-to-create-informative-toast-notification-in-uwp-app
			// slightly modified to get rid of useless stuff

			ToastNotifier ToastNotifier = ToastNotificationManager.CreateToastNotifier();
			// get template for toaster notification
			Windows.Data.Xml.Dom.XmlDocument toastXml = ToastNotificationManager.GetTemplateContent(ToastTemplateType.ToastText02);
			Windows.Data.Xml.Dom.XmlNodeList toastNodeList = toastXml.GetElementsByTagName("text");
			// add custom text
			toastNodeList.Item(0).AppendChild(toastXml.CreateTextNode(title));
			toastNodeList.Item(1).AppendChild(toastXml.CreateTextNode(stringContent));
			// create toaster notification and show it
			ToastNotification toast = new ToastNotification(toastXml) { ExpirationTime = DateTime.Now.AddSeconds(4) };
			ToastNotifier.Show(toast);
		}

	}
}
