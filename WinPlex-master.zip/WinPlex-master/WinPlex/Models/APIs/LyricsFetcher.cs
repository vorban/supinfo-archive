﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace WinPlex.Models
{
	class LyricsFetcher
	{
		private static LyricsFetcher Fetcher { get; set; }
		private static Uri BaseAddress { get; set; }


		private LyricsFetcher()
		{
			// default constructor
		}

		public static LyricsFetcher GetFetcher()
		{
			if (Fetcher == null)
			{
				Fetcher = new LyricsFetcher();
				BaseAddress = new Uri("https://api.lyrics.ovh/v1/");
			}
			return Fetcher;
		}

		public async Task<Song> FetchLyricsAsync(Tuple<String, String> args)
		{
			try
			{
				using (var httpClient = new HttpClient { BaseAddress = new Uri(BaseAddress, args.Item1 + '/' + args.Item2) })
				{
					using (var response = await httpClient.GetAsync(""))
						// deserialize JSON response into a Song object, then return the newly created instance
						return await response.Content.ReadAsAsync<Song>();
				}
			}
			catch (Exception)
			{
				return new Song { Lyrics = "Cannot fetch lyrics - API is probably down" };
			}
		}

	}
}
