﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace WinPlex.Models.APIs
{
	public class VimeoClient
	{
		private const String ClientIdentifier = "f91243623c3b64dbf3186a79ec553f4f0001b128";
		private const String ClientSecret = "tRhbgFHGpgVje9CeeE3JDak+6jZMMSOeoeSWSXgm/yCx+GliMyTbVo8R5jB4pQqcUkoOYEfscRzwlkKFrKMCvKPj1fVVmpllMa4wU2CV55GIhZTyaHVBMAiU/r0Hbt+7";
		private const String BaseURL = "https://api.vimeo.com/";
		private const String UnAuthURL = "oauth/authorize/client";
		
		private static VimeoClient _vc;

		private HttpClient client;
		private String token = "";
		

		private VimeoClient()
		{
			// default constructor
			client = new HttpClient();
			// need a new token
			RequestToken();
		}

		public static VimeoClient GetVimeoClient()
		{
			if (_vc == null) _vc = new VimeoClient();
			return _vc;
		}

		public async void RequestToken()
		{
			String base64Encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(ClientIdentifier + ':' + ClientSecret));
			try
			{
				// content = request params
				FormUrlEncodedContent requestParams = new FormUrlEncodedContent(
					new Dictionary<string, string>
					{
						{ "grant_type", "client_credentials" }
					}
				);
				// add auth header
				client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("basic", base64Encoded);

				HttpResponseMessage response = await client.PostAsync(BaseURL + UnAuthURL, requestParams);
				String content = await response.Content.ReadAsStringAsync();
				token = JsonValue.Parse(content).GetObject().GetNamedString("access_token");
			}
			catch (Exception e)
			{
				System.Diagnostics.Debug.WriteLine(e.Message);
				token = "invalid";
			}
		}

		public async Task<String> GetFirstVideoLink(Tuple<String,String> requestParams)
		{
			try
			{
				// the request could eventually be done before the token is actually retrieved
				if (token == "")
				{
					// request the token once again - if another request is pending, this will not cause any problem - just override the first value
					RequestToken();
					// wait for token to be updated
					do { } while (token == "");
				}
				// if token is invalid throw exception
				if (token == "invalid") throw new Exception("Cannot query Vimeo API: The app token is invalid. It is possible that it could not be retrieved.");

				client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
				HttpResponseMessage response = await client.GetAsync(
					BaseURL
					+ "videos?page=1&per_page=1&query="
					+ requestParams.Item1 + " " + requestParams.Item2
					+ "&sort=relevant"
				);
				String content = await response.Content.ReadAsStringAsync();

				String iframe = JsonValue.Parse(content).GetObject() // parse to json
								.GetNamedArray("data").First().GetObject() // get first video in videos array
								.GetNamedObject("embed").GetNamedString("html"); // get video's embed html iframe
																				 // extract src
				System.Diagnostics.Debug.WriteLine(iframe);

				HtmlDocument htmlDoc = new HtmlDocument();
				htmlDoc.LoadHtml(iframe);

				String src = htmlDoc.DocumentNode
					.SelectSingleNode("//iframe")
					.Attributes["src"].Value;

				System.Diagnostics.Debug.WriteLine(" ===== " + src + " ===== ");
				
				return src;
			}
			catch (Exception e)
			{
				System.Diagnostics.Debug.WriteLine(e.Message);
				return "";
			}
		}
	}
}
