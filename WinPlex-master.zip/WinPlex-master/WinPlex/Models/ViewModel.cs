﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinPlex.Models
{
	public class ViewModel: INotifyPropertyChanged
	{
		private Song _song;
		public Song Song
		{
			get { return _song; }
			set
			{
				_song = value;
				NotifyPropertyChanged("Song");
			}
		}

		public ViewModel()
		{
			Song = new Song();
		}

		public void NotifyPropertyChanged(String property) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
