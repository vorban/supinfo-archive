﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace WinPlex.Models
{
	public class DataPersistenceManager
	{
		private static DataPersistenceManager _dpm;

		private ApplicationDataContainer localSettings;
		private StorageFolder localFolder;

		private DataPersistenceManager()
		{
			// default constructor
			localSettings = ApplicationData.Current.LocalSettings;
			localFolder = ApplicationData.Current.LocalFolder;
			// debug : uncomment following line to erase theme save
			// localSettings.Values.Remove("theme");
		}

		public static DataPersistenceManager GetDataPersistenceManager()
		{
			if (_dpm == null) _dpm = new DataPersistenceManager();
			return _dpm;
		}

		public void AddSetting<T>(String settingName, T value)
		{
			localSettings.Values[settingName] = value ;
		}

		public object GetSetting(String settingName)
		{
			return localSettings.Values[settingName];
		}

		public bool Contains(String settingName)
		{
			return localSettings.Values.ContainsKey(settingName);
		}
	}
}
