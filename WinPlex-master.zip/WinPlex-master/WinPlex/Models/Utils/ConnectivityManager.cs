﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Connectivity;

namespace WinPlex.Models
{
	public class ConnectivityManager
	{
		// this class is heavily inspired by https://blog.jayway.com/2015/04/23/how-to-verify-internet-access-in-universal-apps/

		private static ConnectivityManager _cm;

		public bool InternetAccessible { get; set; }

		private ConnectivityManager()
		{
			// default constructor
			// add function as eventlistener
			NetworkInformation.NetworkStatusChanged += NetworkStatusChangedEventHandler;
			// init InternetAccessible value for instant use
			NetworkStatusChangedEventHandler(null);
		}

		public static ConnectivityManager GetConnectivityManager()
		{
			if (_cm == null) _cm = new ConnectivityManager();
			return _cm;
		}

		private void NetworkStatusChangedEventHandler(Object sender)
		{
			ConnectionProfile connectionProfile = NetworkInformation.GetInternetConnectionProfile();
			InternetAccessible = (connectionProfile != null &&
								 connectionProfile.GetNetworkConnectivityLevel() == NetworkConnectivityLevel.InternetAccess);
		}



	}
}
