﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace WinPlex.Models
{
	public class AssetManager
	{
		public BitmapIcon SunDarkIcon { get; set; }
		public BitmapIcon SunLightIcon { get; set; }

		private static AssetManager _am;

		private AssetManager()
		{
			// default constructor
			SunDarkIcon = new BitmapIcon { UriSource = new Uri("ms-appx:///Assets/sun-dark.png") };
			SunLightIcon = new BitmapIcon { UriSource = new Uri("ms-appx:///Assets/sun-light.png") };
		}

		public static AssetManager GetAssetManager()
		{
			if (_am == null) _am = new AssetManager();
			return _am;
		}

	}
}
