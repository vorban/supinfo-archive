﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinPlex.Models
{
	public class Song
	{
		// property with lowercase 'l' needed for JSON deserialization
		private String lyrics { get; set; }

		public String Lyrics
		{
			get { return lyrics; }
			set
			{
				lyrics = value;
			}
		}

		public Song()
		{
			lyrics = "No lyrics found yet";
		}
	}
}
