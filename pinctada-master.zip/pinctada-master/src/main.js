const { app, ipcMain } = require('electron');

const Window = require('./window.js');
const Utils = require('./utils.js');
const Controller = require('./controller.js');

const WEB_PATH = 'web/';
const KEYFILE_PATH = 'keyfiles/';

function main() {
  let window = new Window({});
  window.on('closed', () => {
    window = null;
  });

  Controller.login_GET(window);

  ipcMain.on('index', (event, args) => Controller.index_GET(window));
  ipcMain.on('transaction', (event, args) => Controller.transaction_GET(window));
  ipcMain.on('isValidAddress', (event, args) => Controller.isValidAddress_POST(window, event, args));
  ipcMain.on('send-transaction', (event, args) => Controller.transaction_POST(window, args));
  ipcMain.on('login', (event, args) => Controller.login_POST(window, args));
  ipcMain.on('logout', (event, args) => Controller.logout_POST(window));
  ipcMain.on('register', (event, args) => Controller.register_POST(window, args));
}

app.on('ready', main);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('activate', () => {
  if (win === null) createWindow();
});

// accnt = loadAccount('keyfile', 'password');
// accnt = Utils.loadAccount('admin', 'azertyuiop');
// 0x2691171387e8edeed501a77658ca3552fb6322cd
// accnt = newAccount();
// saveAccount(accnt, 'password', 'keyfile');

// Utils.signTransaction(
//   accnt,
//   '0xd6c4fd58e39fff1a024ad4d89a6a17403add8a59',
//   '5'
// ).then(Utils.sendTransaction).catch(console.log);
