const { BrowserWindow } = require('electron');

const defaultProps = {
  width: 1200,
  height: 780,
  show: false,
  webPreferences: {
    nodeIntegration: true
  }
};

module.exports = class Window extends BrowserWindow {
  constructor ({ ...windowSettings }) {
    super({ ...defaultProps, ...windowSettings});

    this.setMenuBarVisibility(false);
    this.once('ready-to-show', this.show);
  }
};
