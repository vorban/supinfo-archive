web3 = new (require('web3'));
axios = require('axios')
fs = require('fs');

const API_URL = 'http://vorban.ovh:8080/'

module.exports = class Utils {

  static newAccount() {
    return web3.eth.accounts.create();
  }

  static saveAccount(account, password, filename) {
    var signedAccount = web3.eth.accounts.encrypt(account.privateKey, password);
    fs.writeFileSync('./' + filename, JSON.stringify(signedAccount), 'utf8', (err) => {
        if (err) console.log(err);
    });
  }

  static loadAccount(filename, password) {
    try {
      var content = fs.readFileSync(filename,'utf8');
      return web3.eth.accounts.decrypt(content, password);
    } catch (e) {
      console.log(e);
      return null;
    }
  }

  static signTransaction(account, nonce, to, ethValue) {
    return web3.eth.accounts.signTransaction({
      nonce: nonce,
      chainId: 215037,
      from: account.address,
      to: web3.utils.toChecksumAddress(to),
      value: web3.utils.toHex(web3.utils.toWei(ethValue, 'ether')),
      gasPrice: '0x1',
      gas: '0x5208',
      gasLimit: '0x100000000',
      data: '0x'
    }, account.privateKey);
  }

  static getTransactionNonce(account)  {
    return axios.get(API_URL + 'transaction_nonce/' + account.address).then(res => {
      return new Promise(function(resolve, reject) {
        resolve(web3.utils.hexToNumberString(res.data.result));
      });
    });
  }

  static getBalance(account)  {
    return axios.get(API_URL + 'balance/' + account.address).then(res => {
      return new Promise(function(resolve, reject) {
        var balance = web3.utils.hexToNumberString(res.data.result);
        resolve(balance);
      });
    });
  }

  static getEth(weiStr) {
    var str = web3.utils.hexToNumberString(weiStr);
    var balance = web3.utils.fromWei(str, 'ether');

    var index = balance.indexOf('.');
    if (balance.includes('.') && balance.substr(index).length > 4) {
      balance = balance.substr(0, index + 4);
    }

    return balance;
  }

  static getFormattedBalance(weiStr) {
    var balance = Utils.getEth(weiStr);

    var index = balance.indexOf('.');
    for (let i = index - 3; i > 0; i -= 3) {
      balance = balance.substr(0, i) + ' ' + balance.substr(i);
    }

    return balance;
  }

  static sendTransaction(transaction) {
    return axios.post(API_URL + 'send_transaction', {
      transaction: transaction.rawTransaction
    });
  }

  static isValidAddress(address) {
    return web3.utils.isAddress(address, 215037);
  }

}
