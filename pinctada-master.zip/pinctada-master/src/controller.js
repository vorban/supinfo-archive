const fs = require('fs');

const Utils = require('./utils.js');

const WEB_PATH = 'web/';
const KEYFILE_PATH = 'keyfiles/';

module.exports = class Controller {

  static login_GET(window) {
    var keyfiles = fs.readdirSync(KEYFILE_PATH);

    if (keyfiles.length == 0) window.loadFile(WEB_PATH + 'register.html');
    else {
      window.loadFile(WEB_PATH + 'login.html');
      window.webContents.once('did-finish-load', () => {
        window.webContents.send('keyfiles', keyfiles);
      });
    }
  }

  static login_POST(window, args) {
    var account = Utils.loadAccount(KEYFILE_PATH + args.account, args.password);
    if (account == null) {
      window.webContents.send('login-failed');
      return;
    }; // TODO:
    window.pinctada = {
      account: account,
      username: args.account
    };
    Controller.index_GET(window);
  }

  static logout_POST(window) {
    window.pinctada = {};
    Controller.login_GET(window);
  }

  static register_GET(window) {
    var keyfiles = fs.readdirSync(KEYFILE_PATH);
    window.loadFile(WEB_PATH + 'register.html');

    window.webContents.on('did-finish-load', () => {
      window.webContents.send('keyfiles', keyfiles);
    });
  }

  static register_POST(window, args) {
    var account = Utils.newAccount();
    Utils.saveAccount(account, args.password, KEYFILE_PATH + args.account);
    Controller.login_GET(window);
  }

  static index_GET(window) {
    window.loadFile(WEB_PATH + 'index.html');
    Utils.getTransactionNonce(window.pinctada.account).then(res => {
      window.pinctada.nonce = res;
      return Utils.getBalance(window.pinctada.account);
    }).then(res => {
      window.pinctada.balance = Utils.getFormattedBalance(res);
      window.pinctada.actualBalance = Utils.getEth(res);
      window.webContents.once('did-finish-load', () => {
        window.webContents.send('session-index', {
          nonce: window.pinctada.nonce,
          balance: window.pinctada.balance,
          account: window.pinctada.account.address,
          username: window.pinctada.username
        });
      });
    });
  }

  static transaction_GET(window) {
    window.loadFile(WEB_PATH + 'transaction.html');
    window.webContents.once('did-finish-load', () => {
      window.webContents.send('session-transaction', {
        balance: window.pinctada.balance,
        actualBalance: window.pinctada.actualBalance
      });
    });
  }

  static transaction_POST(window, args) {
    Utils.signTransaction(
      window.pinctada.account,
      window.pinctada.nonce,
      args.recipient, args.amount
    ).then(Utils.sendTransaction).then(res => {
      window.webContents.send('transaction-reply', true);
    }).then(console.log);
  }

  static isValidAddress_POST(window, evt, args) {
    evt.returnValue = Utils.isValidAddress(args.address);
  }

}
