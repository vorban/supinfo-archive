# pinctada
Ethereum wallet in nodejs, using web3.js
