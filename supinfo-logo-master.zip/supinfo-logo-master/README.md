# supinfo-logo

## Requirements
- Node.js
- npm

## Build
`npm run build`

## Usage
Open src/index.html