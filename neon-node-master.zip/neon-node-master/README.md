# neon-node
Neon's Ethereum private network individual node.

## What does it do ?

This is a node of the private Ethereum network. On startup, it initialize itself using the genesis file. It uses the bootnode service to find peers.

It doesn't do anything asis. It provides a JSON RPC API available through HTTP, which is not published outside the Swarm cluster.
