#!/bin/sh

# if geth is not initialized, do so
if [[ ! -d /root/.ethereum/geth ]]; then
	echo "# ----- NODE INITIALIZING ----- #"
	# init geth using our genesis file
	geth init /root/genesis.json
	# # copy account data to ethereum folder
	# PATH_TO_ACC=/root/credentials
	# ACC=$(ls $PATH_TO_ACC | grep UTC)
	cp /root/credentials/miner /root/.ethereum/keystore/
fi

echo "# ----- NODE STARTING ----- #"
# run geth console
geth \
	--ipcdisable \
	--rpcapi eth,admin,miner,personal,net \
	--rpc \
	--rpcaddr 0.0.0.0 \
	--rpcvhosts=* \
	--networkid 215037 \
	--nodiscover \
	--maxpeers 1 \
	--gasprice "1" \
	--unlock "85f52f74bdfe975695ebc2d413232ed63e391498" \
	--password /root/credentials/password.txt
