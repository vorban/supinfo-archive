// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
#include <string>
#include <iostream>

#include "Cell.h"
#include "Tetriminos.h"
#include "Game.h"
#include "Utilities.h"



// TODO: reference additional headers your program requires here
