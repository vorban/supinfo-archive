# Pentago
The Pentago board game made in Python.
