const express = require('express');
const axios = require('axios');
const db = require('../models/connection.js');
const auth = require('./auth.js');
var router = express.Router();

const API_URL = 'http://papi/';

router.get('/', auth, function(req, res, next) {
  res.render('index');
});

router.get('/blocks', auth, async function(req, res, next) {
  var response = await axios.get(API_URL + 'block_number');
  var data = parseInt(response.data.result, 16);

  var start = data - req.query.start;
  var end = (start - req.query.length >= 0) ? (start - req.query.length) : 0;

  var blocks = await getBlocks(start,end);

  res.send({
    draw: req.query.draw,
    recordsTotal: data,
    recordsFiltered: data,
    data: blocks.sort(compareBlocks).reverse()
  });
});

router.get('/transactions/:block', auth, async function (req, res, next) {
  var result = await axios.get(API_URL + 'block/' + req.params.block);
  var web3 = new (require('web3'));
  res.render('transactions', {
    block: result.data.result,
    getFormattedBalance: function (weiStr) {
      var str = web3.utils.hexToNumberString(weiStr);
      var balance = web3.utils.fromWei(str, 'ether');

      var index = balance.indexOf('.');
      if (balance.includes('.') && balance.substr(index).length > 4) {
        balance = balance.substr(0, index + 4);
      }

      index = balance.indexOf('.');
      for (let i = index - 3; i > 0; i -= 3) {
        balance = balance.substr(0, i) + ' ' + balance.substr(i);
      }

      return balance;
    }
  });
});

function getBlocks(firstBlock, lastBlock) {
  return new Promise(async function(resolve, reject) {
    if (firstBlock == lastBlock) {
      resolve([]);
      return;
    }

    var res = await axios.get(API_URL + 'block/0x' + firstBlock.toString(16))
    let block = res.data.result;

    block = [
      block.number,
      block.hash,
      block.parentHash,
      block.timestamp,
      {
        length: block.transactions.length,
        link: '/transactions/' + block.number
      }
    ];

    var blocks = await getBlocks(firstBlock - 1, lastBlock);
    resolve([block].concat(blocks));
  });
}

function compareBlocks(a, b) {
  if (parseInt(a[0], 16) < parseInt(b[0], 16)) return -1;
  if (parseInt(a[0], 16) > parseInt(b[0], 16)) return 1;
  return 0;
}

module.exports = router;
