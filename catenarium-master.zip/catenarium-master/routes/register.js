const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/user.js');
const router = express.Router();

router.get('/', function(req, res, next) {
  res.render('register');
});

router.post('/', async function(req, res, next) {
  var user = await User.get({
    email: req.body.email
  });
  if (user != undefined) {
    res.render(register);
    return;
  }
  var password = await bcrypt.hash(req.body.password, 10);
  var user = new User(req.body.email, password);
  user.save().then(() => {
    res.redirect('/login');
  });
});

router.post('/validateusername', async function (req, res, next) {
  var user = await User.get({
    email: req.body.email
  });
  res.send({
    validated: user == undefined
  });
});

module.exports = router;
