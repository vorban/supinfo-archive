const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/user.js');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('login');
});

router.post('/', async function(req, res, next) {
  var user = await User.get({
    email: req.body.email
  });
  if (user == undefined || !await bcrypt.compare(req.body.password, user.password)) {
    res.render('login');
    return;
  }

  req.catenarium.user = user;
  res.redirect('/');
});

router.get('/logout', function(req, res, next) {
  if (req.catenarium.user) req.catenarium.user = undefined;
  res.redirect('/login');
});

module.exports = router;
