var mysql = require('mysql');

function sleep(ms){
  return new Promise(resolve=>{
    setTimeout(resolve,ms)
  });
}

module.exports = new class Connection {
  constructor() {
    this.pool = mysql.createPool({
      connectionLimit: 10,
      host     : 'db',
      user     : 'catenarium',
      password : 'catenariumpassword',
      database : 'neon'
    });
    this.init();
  }

  init() {
    this.createUserTable().then(() => {
      console.log("MySQL connection established");
    }).catch(async err => {
      console.log(err);
      console.log("MySQL connection error. Retrying in 5 sec...");
      await sleep(5000);
      this.init();
    });
  }

  query(sql) {
    return new Promise((resolve, reject) => {
      this.pool.query(sql, (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }

  close() {
    return new Promise((resolve, reject) => {
      this.pool.end(err => {
        if (err) return reject(err);
        resolve();
      })
    });
  }

  createUserTable() {
    var sql = 'CREATE TABLE IF NOT EXISTS `user` ('
      + '`id` INT unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,'
      + '`email` VARCHAR(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT "",'
      + '`password` VARCHAR(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT "");';
    return this.query(sql);
  }
};
