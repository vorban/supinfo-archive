const db = require('./connection.js');

module.exports = class User {
  constructor(email, password) {
    this.email = email || '';
    this.password = password || '';
  }

  save() {
    var sql = 'INSERT INTO user (email, password) VALUES ("' + this.email + '", "' + this.password + '");';
    return db.query(sql);
  }

  static get(args) {
    var sql = 'SELECT * FROM user';
    if (args == undefined) {
      sql += ';';
      return db.query(sql);
    }

    sql += ' WHERE ';

    if (args.email != undefined) {
      sql += 'email = "' + args.email + '"';
    }

    if (args.password != undefined) {
      sql += ' AND password = "' + args.password + '"';
    }

    sql += ';';

    return db.query(sql).then(rows => {
      return new Promise((resolve, reject) => {
        if (rows.length == 0) resolve();
        else if (rows.length == 1) resolve(new User(rows[0].email, rows[0].password));
        else {
          var users = [];
          rows.forEach(row => {
            users.push(new User(row[0].email, row[0].password))
          });
          resolve(users);
        }
      });
    }).catch(console.log);
  }

}
