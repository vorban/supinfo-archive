#!/bin/sh

# if [[ ! -f ./boot.key ]]; then
# 	echo "# ----- BOOTNODE KEYGEN ----- #"
# 	bootnode --verbosity 5 --genkey=./boot.key
# fi

echo "# ----- BOOTNODE STARTING ----- #"
bootnode --nodekey=/root/boot.key --writeaddress
bootnode --verbosity 5 --nodekey=/root/boot.key
