# neon-bootnode
Bootnode for Neon's Ethereum private network

## What does it do ?

When a geth node is up, it will contact the present bootnode to gather information about peers. No blockchain data is available on this bootnode.

The `bootnode.sh` script will start the bootnode, displaying it's enode url.

## How to use it ?

`cd` into the project.

To build the docker image, run `docker build -t valentinorban/neon:bootnode .`

This image is supposed to be run in a docker swarm environment.
