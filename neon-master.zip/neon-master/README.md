# Neon

4PJT

## Deploy on a swarm cluster

```shell
docker stack deploy -c docker-compose.yml --with-registry-auth
```

## Thought updates

The full environment is contained in a `Docker Swarm Mode` cluster:
- Geth node service
- Geth bootnode service
- Python backend service
- Laravel frontend service

Each service has it's own git repository.
Each service probably will have its custom docker image


## Snippets

Visualizer :
```shell
docker service create \
--name=viz \
--publish=4040:8080/tcp \
--constraint=node.role==manager \
--mount=type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock \
dockersamples/visualizer
```

```shell
docker service create \
--name=bootnode \
--with-registry-auth \
valentinorban/neon:bootnode
```


## Reminders

Get IP address (subnet beginning with 172) from inside the container :
```shell
cat /etc/hosts | grep -E "172" | cut -f1
```

Append `--ipcdisable --rpc --rpcaddr 0.0.0.0 --rpcvhosts=* --networkid 215037` in each `geth` command

Get docker-compose containers IPs :
```shell
docker inspect -f '{{.Name}} - {{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' $(docker ps -aq)
```

Get enode with `geth --exec "admin.nodeInfo.enode" console`

Mine with `--mine --minerthreads=1 --etherbase="$(< /root/account.txt)"`
