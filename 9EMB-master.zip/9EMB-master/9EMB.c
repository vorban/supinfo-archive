#include <LiquidCrystal.h>
#include <Keypad.h>

// ----- piezo ----- //
// mapped on 6
#define PIEZO 6

#define C4 262
#define C4S 277
#define D4 294
#define D4S 311
#define E4 330
#define F4 349
#define F4S 370
#define G4 392
#define G4S 412
#define A4 440
#define A4S 466
#define B4 494

#define WHOLE 2000
#define HALF 1000
#define QUARTER 500
#define EIGHTH 250

// ----- KEYPAD ----- //
// rows 1 2 3 4 mapped on 13 12 11 10
// columns 1 2 3 mapped on 9 8 7
#define ROWS 4
#define COLS 4
const char keymap[ROWS][COLS] = {
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'},
    {'*', '0', '#'}
};
byte ROW_PINS[ROWS] = {13, 12, 11, 10};
byte COL_PINS[COLS] = {9, 8, 7};

Keypad keypad = Keypad(
    makeKeymap(keymap),
    ROW_PINS, COL_PINS,
    ROWS, COLS
);

// ----- LCD ----- //
// pins DB 4 5 6 7 mapped on 2 3 4 5 digital pins
// pins RS E mapped on 0, 1 digital pins
LiquidCrystal lcd(0, 1, 2, 3, 4, 5);


void playAsync(int frequency, int duration) {
    tone(PIEZO, frequency, duration);
}

void playSync(int frequency, int duration) {
    playAsync(frequency, duration);
    delay(duration + 10);
}


void setup() {
    lcd.begin(16, 2);
    pinMode(PIEZO, OUTPUT);
}

void loop() {
    playSync(C4, EIGHTH);
    playSync(D4, QUARTER);
    playSync(E4, EIGHTH);
    playSync(F4, QUARTER);
    playSync(G4, EIGHTH);
    playSync(A4, QUARTER);
    playSync(B4, EIGHTH);
    // lcd.setCursor(5, 0);
    // lcd.print(0);
    // lcd.setCursor(8, 0);
    // lcd.print('%');
    // delay(500);
    // for (int i = 0; i < 16; i++) {
    //     lcd.setCursor(i, 1);
    //     lcd.write(1);
    //     lcd.setCursor(5, 0);
    //     lcd.print((i + 1) * 100 / 16);
    //     delay(500);
    // }
    // lcd.clear();
}