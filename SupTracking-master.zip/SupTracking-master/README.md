# SupTracking
School Apple Project

Members :
  - Louis Chevalier - Starfox64
  - Alois Ceola - Dauflo
  - Valentin Orban - KhroyaenSkrafhar

Info :
- All the files corresponding to the XCode project are under : /src
- The original project specifications are listed in the .pdf file under : /
