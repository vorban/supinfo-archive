//
//  LoginPage.swift
//  SupTracking
//
//  Created by Supinfo on 20/12/17.
//  Copyright © 2017 Supinfo. All rights reserved.
//

import UIKit

class LoginPage: UIViewController {
    
    @IBOutlet weak var userNameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    @IBAction func testGetButton(_ sender: Any) {
        let userName = userNameText.text
        let password = passwordText.text
        let login = "login"
        /*let url = URL(string: "https://jsonplaceholder.typicode.com/users")
        
        let session = URLSession.shared
        
        session.dataTask(with: url!) {
            (data, reponse, error) in if let reponse = reponse {
                print(reponse)
            }
            if let data = data {
                print(data)
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print("error")
                }
            }
        }.resume()*/
        let parameters = ["action": "login", "login": userName, "password": password]
        //let parameters = "actrion=\(login)&login=\(userName)&password=\(password)"
        
        let url = URL(string: "http://supinfo.steve-colinet.fr/suptracking/")
        //let url = URL(string: "https://jsonplaceholder.typicode.com/posts")
        var request = URLRequest(url: url!)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) {
            (data, response, error) in if let response = response {
                print(response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
    
    @IBAction func loginButton(_ sender: Any) {
        let userName = userNameText.text
        let password = passwordText.text
        
        
        if (userName == "admin") {
            if (password == "admin") {
                performSegue(withIdentifier: "segueMap", sender: nil)
            }
        }
        if ((userName?.isEmpty)! || (password?.isEmpty)!) {
            displayPopUp(userTitle: "Missing informations", userMessage: "Please complete all fields")
        }
        if (password != "admin") {
            displayPopUp(userTitle: "Error", userMessage: "Informations do not match")
        }
    }
    
    
    //Display du about us
    @IBAction func aboutUsButton(_ sender: UIButton) {
        displayPopUp(userTitle: "Qui sommes nous", userMessage: "La team")
    }
    
    //Fonction about us, display dun pop up
    func displayPopUp(userTitle: String, userMessage: String) {
        let monAlerte = UIAlertController(title:userTitle, message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        
        monAlerte.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(monAlerte, animated:true, completion:nil)
    }
}
