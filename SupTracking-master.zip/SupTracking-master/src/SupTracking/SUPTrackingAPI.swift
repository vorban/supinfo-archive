import Foundation

struct User {
    var id: Int = 0
    var username: String = ""
    var password: String = ""
    var phone: String = ""
    var firstName: String = ""
    var lastName: String = ""
    var postalCode: String = ""
    var address: String = ""
    var email: String = ""
}

class SUPTrackingAPI {
    internal static func postRequest(data: [String : String], withHandler handler: @escaping ([String : Any], NSError?) -> Void) -> Void {
        let url = URL(string: "http://supinfo.steve-colinet.fr/suptracking/") //http://supinfo.steve-colinet.fr/suptracking
        var request = URLRequest(url: url!)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        var postString = ""
        var firstParam = true
        
        for (k, v) in data {
            if (!firstParam) {
                postString += "&"
            }
            
            firstParam = false
            
            k.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)
            v.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)

            postString += "\(k)=\(v)"
        }

        request.httpBody = postString.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let data = data {
                do {
                    
                    //print(NSString(data: data, encoding: String.Encoding.ascii.rawValue)!)
                    let jsonSerialized = try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any]
                    
                    handler(jsonSerialized!, nil)
                }  catch let error as NSError {
                    print(error.localizedDescription)
                }
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
    }

    static func login(username: String, withPassword password: String, withHandler handler: @escaping (User?) -> Void) -> Void {
        self.postRequest(data: [
            "action": "login",
            "login": username,
            "password": password
            ], withHandler: {data, error in
                if (error != nil) {return handler(nil)}
                
                let success = data["success"] as? Bool
                
                if (success)! {
                    let userData = data["user"] as! [String : Any]
                    
                    let user = User(
                        id: userData["id"] as! Int,
                        username: userData["username"] as! String,
                        password: userData["password"] as! String,
                        phone: userData["phone"] as! String,
                        firstName: userData["firstname"] as! String,
                        lastName: userData["lastname"] as! String,
                        postalCode: userData["postalCode"] as! String,
                        address: userData["address"] as! String,
                        email: userData["email"] as! String
                    )
                    
                    handler(user)
                } else {
                    handler(nil)
                }
        })
    }
}

// How To Use it
SUPTrackingAPI.login(username: "admin", withPassword: "admin", withHandler: {user in
    print(user!)
})
