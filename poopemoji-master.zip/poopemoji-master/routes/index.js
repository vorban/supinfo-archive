var express = require('express');
var router = express.Router();

const { fetchAll, model } = require('../services/db');

/* GET home page. */
router.get('/', async function(req, res, next) {
  res.render('index');
});


// I. Who are the most successful students, depending on the region / institution of origin, etc.
router.get('/dataI', async function(req, res, next) {
  // average credit by campus
  let avgCreditByCampus = await model.aggregate([{
    $group: {
      _id: "$campus",
      avgCredit: {
        $avg: {
          $divide: ["$credit", "$promotion"]
        }
      }
    }
  }]);

  avgCreditByCampus = avgCreditByCampus.reduce((o, value) => {
    o[value._id] = value.avgCredit;
    return o;
  }, {});

  // average credit by city
  let avgCreditByCity = await model.aggregate([{
    $group: {
      _id: "$city",
      avgCredit: {
        $avg: {
          $divide: ["$credit", "$promotion"]
        }
      }
    }
  }]);

  avgCreditByCity = avgCreditByCity.reduce((o, value) => {
    o[value._id] = value.avgCredit;
    return o;
  }, {});

  res.json({
    avgCreditByCity: avgCreditByCity,
    avgCreditByCampus: avgCreditByCampus
  });
});


// III. Why there are more students in one region and few in another
router.get('/dataIII', async function (req, res, next) {
  let studentsByCampus = await model.aggregate([{
    $group: {
      _id: "$campus",
      count: { $sum: 1 }
    }
  }]);

  studentsByCampus = studentsByCampus.reduce((o, value) => {
    o[value._id] = value.count;
    return o;
  }, {});

  let studentsByCity = await model.aggregate([{
    $group: {
      _id: "$city",
      count: { $sum: 1 }
    }
  }]);

  studentsByCity = studentsByCity.reduce((o, value) => {
    o[value._id] = value.count;
    return o;
  }, {});

  res.json({
    studentsByCampus: studentsByCampus,
    studentsByCity: studentsByCity
  });
});

// V. What is the impact of a student fair on recruitments
router.get('/dataV', async function (req, res, next) {
  let data = await model.aggregate([{
    $group: {
      _id: "$knowledge",
      count: { $sum: 1 }
    }
  }]);

  data = data.reduce((o, value) => {
    o[value._id] = value.count;
    return o;
  }, {});

  res.json(data);
});

// X. What are the school's growth forecasts
router.get('/dataX', async function (req, res, next) {
  let data = await model.aggregate([{
    $group: {
      _id: { $year: "$startDate" },
      count: { $sum: 1 }
    }
  }]);

  data = data.reduce((o, value) => {
    o[value._id] = value.count;
    return o;
  }, {});

  res.json(data);
});


module.exports = router;
