const mongo = require('mongoose');

const schema = new mongo.Schema({
    city: String,
    birthDate: Date,
    campus: String,
    promotion: Number,
    degree: String,
    knowledge: String,
    startDate: Date,
    eatOnCampus: Boolean,
    credit: Number,
    parentHome: Boolean,
    laboContribution: Boolean,
    numberResit: Number,
}, { collection: 'project' })

const Entity = mongo.model('Project', schema);

exports.connect = function () {
        mongo.connect(process.env.MONGO_URI || 'mongodb+srv://data:Supinf0.@cluster-test-yuoaw.gcp.mongodb.net/test?retryWrites=true&w=majority', {
            useNewUrlParser: true,
            dbName: 'data'
        });
        mongo.connection.on('error', console.error.bind('connection error:'));
        mongo.connection.once('open', () => console.log('Connected to db.'));
}

exports.model = Entity;
